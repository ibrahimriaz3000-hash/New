Dynamic Pill (LSPosed module)
1. Upload this zip to a GitHub repo, add .github/workflows/build.yml.
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. There is no launcher icon: add the "Dynamic Pill" tile in Control Center (Edit); it switches pill and line together,
   long press a tile (or use LSPosed module settings) to open the settings screen.
